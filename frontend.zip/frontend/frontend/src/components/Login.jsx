import { useState } from "react";

export default function Login({ setUsername, setGame }) {
  const [name, setName] = useState("");

  function connect() {
    setUsername(name);
  }

  return (
    <div>
      <h2>Enter Username</h2>
      <input value={name} onChange={e => setName(e.target.value)} />
      <button onClick={connect}>Play</button>
    </div>
  );
}
