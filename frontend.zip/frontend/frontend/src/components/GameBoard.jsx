import { useEffect, useState } from "react";

export default function GameBoard({ username, game, setGame }) {
  const [ws, setWs] = useState(null);
  const [board, setBoard] = useState(Array(6).fill(Array(7).fill(0)));

  useEffect(() => {
    const socket = new WebSocket(`ws://localhost:8080/ws?username=${username}`);
    socket.onopen = () => socket.send(JSON.stringify({ type: "join" }));

    socket.onmessage = (msg) => {
      const data = JSON.parse(msg.data);
      console.log("WS:", data);

      if (data.type === "match") setGame(data.game);
      if (data.type === "update") setBoard(data.board);
      if (data.type === "game_over") alert("Winner: " + data.winner);
    };

    setWs(socket);
  }, []);

  function drop(col) {
    if (!game) return;
    ws.send(JSON.stringify({ type: "move", column: col, gameId: game.id }));
  }

  return (
    <div>
      <h2>Game Board</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 60px)" }}>
        {board.flatMap((row, r) =>
          row.map((cell, c) => (
            <div
              key={`${r}-${c}`}
              onClick={() => drop(c)}
              style={{
                width: 60, height: 60, border: "1px solid black",
                background: cell === 1 ? "red" : cell === 2 ? "yellow" : "white",
              }}
            />
          ))
        )}
      </div>
    </div>
  );
}
