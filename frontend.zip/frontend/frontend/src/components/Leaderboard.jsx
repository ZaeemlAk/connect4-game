import { useEffect, useState } from "react";

export default function Leaderboard() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/leaderboard")
      .then(r => r.json())
      .then(setData);
  }, []);

  return (
    <div>
      <h2>Leaderboard</h2>
      {data.map((u, i) => (
        <div key={i}>{u.username} — {u.wins} wins</div>
      ))}
    </div>
  );
}
