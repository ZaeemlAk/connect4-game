import { useState } from "react";
import Login from "./components/Login";
import GameBoard from "./components/GameBoard";
import Leaderboard from "./components/Leaderboard";

export default function App() {
  const [username, setUsername] = useState("");
  const [game, setGame] = useState(null);

  return (
    <div style={{ padding: 20 }}>
      {!username && <Login setUsername={setUsername} setGame={setGame} />}
      {username && <GameBoard username={username} game={game} setGame={setGame} />}
      <Leaderboard />
    </div>
  );
}
