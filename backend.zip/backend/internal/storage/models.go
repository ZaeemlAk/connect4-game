package storage

import "time"

type GameRecord struct {
    ID        string `gorm:"primaryKey"`
    Player1   string
    Player2   string
    Winner    int
    CreatedAt time.Time
}
