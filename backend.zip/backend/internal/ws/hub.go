package ws

import (
    "sync"
)

type Hub struct {
    clients    map[string]*Client
    register   chan *Client
    unregister chan *Client
    mu         sync.RWMutex
}

func NewHub() *Hub {
    return &Hub{
        clients:    make(map[string]*Client),
        register:   make(chan *Client),
        unregister: make(chan *Client),
    }
}

func (h *Hub) Run() {
    for {
        select {
        case c := <-h.register:
            h.mu.Lock()
            h.clients[c.Username] = c
            h.mu.Unlock()

        case c := <-h.unregister:
            h.mu.Lock()
            if _, ok := h.clients[c.Username]; ok {
                delete(h.clients, c.Username)
                close(c.send)
            }
            h.mu.Unlock()
        }
    }
}

func (h *Hub) SendToUser(user string, msg []byte) {
    h.mu.RLock()
    defer h.mu.RUnlock()
    if c, ok := h.clients[user]; ok {
        c.send <- msg
    }
}
