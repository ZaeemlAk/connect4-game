package ws

import (
    "encoding/json"
    "log"
    "net/http"

    "github.com/gorilla/websocket"
    "connect4-backend/internal/matchmaking"
    "connect4-backend/internal/game"
)

var upgrader = websocket.Upgrader{
    CheckOrigin: func(r *http.Request) bool { return true },
}

type Client struct {
    Conn     *websocket.Conn
    send     chan []byte
    Username string
}

func ServeWS(hub *Hub, matcher *matchmaking.Matcher, gm *game.Manager) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        username := r.URL.Query().Get("username")
        if username == "" {
            http.Error(w, "missing username", http.StatusBadRequest)
            return
        }

        conn, err := upgrader.Upgrade(w, r, nil)
        if err != nil {
            log.Println(err)
            return
        }

        client := &Client{
            Conn:     conn,
            send:     make(chan []byte, 256),
            Username: username,
        }

        hub.register <- client

        go client.writePump()
        go client.readPump(hub, matcher, gm)
    }
}

func (c *Client) readPump(hub *Hub, matcher *matchmaking.Matcher, gm *game.Manager) {
    defer func() {
        hub.unregister <- c
        c.Conn.Close()
    }()

    for {
        _, data, err := c.Conn.ReadMessage()
        if err != nil {
            return
        }

        var msg map[string]interface{}
        json.Unmarshal(data, &msg)

        switch msg["type"] {
        case "join":
            matcher.JoinQueue(c.Username)

        case "move":
            col := int(msg["column"].(float64))
            gameID := msg["gameId"].(string)
            g, ok := gm.GetGame(gameID)
            if ok {
                gm.Move(g, col, g.Turn)
            }
        }
    }
}

func (c *Client) writePump() {
    for msg := range c.send {
        c.Conn.WriteMessage(websocket.TextMessage, msg)
    }
}
