package matchmaking

import (
    "sync"
    "time"

    "connect4-backend/internal/game"
)

type Matcher struct {
    queue     []string
    mu        sync.Mutex
    gameMgr   *game.Manager
}

func NewMatcher(gm *game.Manager) *Matcher {
    return &Matcher{
        queue:   []string{},
        gameMgr: gm,
    }
}

func (m *Matcher) Run() {
    for {
        time.Sleep(1 * time.Second)
        m.matchLoop()
    }
}

func (m *Matcher) JoinQueue(user string) {
    m.mu.Lock()
    defer m.mu.Unlock()

    m.queue = append(m.queue, user)
}

func (m *Matcher) matchLoop() {
    m.mu.Lock()
    defer m.mu.Unlock()

    if len(m.queue) == 0 { return }

    if len(m.queue) >= 2 {
        // Match two players
        p1 := m.queue[0]
        p2 := m.queue[1]
        m.queue = m.queue[2:]
        m.gameMgr.CreateGame(p1, p2)
        return
    }

    // Only 1 player → try bot after 10 seconds
    if len(m.queue) == 1 {
        time.AfterFunc(10*time.Second, func() {
            m.mu.Lock()
            defer m.mu.Unlock()
            if len(m.queue) == 1 {
                p1 := m.queue[0]
                m.queue = []string{}
                m.gameMgr.CreateGame(p1, "BOT")
            }
        })
    }
}
