package kafka

import (
    "context"
    "log"

    "github.com/segmentio/kafka-go"
)

type Producer struct {
    writer *kafka.Writer
}

func NewProducer(broker string) *Producer {
    return &Producer{
        writer: &kafka.Writer{
            Addr:     kafka.TCP(broker),
            Topic:    "game-events",
            Balancer: &kafka.LeastBytes{},
        },
    }
}

func (p *Producer) Send(payload []byte) {
    err := p.writer.WriteMessages(context.Background(), kafka.Message{
        Value: payload,
    })
    if err != nil {
        log.Println("Kafka write failed:", err)
    }
}
