package kafka

import (
    "encoding/json"
    "connect4-backend/internal/game"
)

func (p *Producer) EmitGameCreated(g *game.Game) {
    evt := map[string]interface{}{
        "type": "GAME_CREATED",
        "gameId": g.ID,
        "player1": g.Player1,
        "player2": g.Player2,
    }
    b, _ := json.Marshal(evt)
    p.Send(b)
}

func (p *Producer) EmitMove(g *game.Game, col int, player int) {
    evt := map[string]interface{}{
        "type":    "PLAYER_MOVE",
        "gameId":  g.ID,
        "column":  col,
        "player":  player,
    }
    b, _ := json.Marshal(evt)
    p.Send(b)
}

func (p *Producer) EmitGameOver(g *game.Game) {
    evt := map[string]interface{}{
        "type":   "GAME_OVER",
        "gameId": g.ID,
        "winner": g.Winner,
    }
    b, _ := json.Marshal(evt)
    p.Send(b)
}
