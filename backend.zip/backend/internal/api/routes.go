package api

import (
    "github.com/gorilla/mux"
    "net/http"

    "gorm.io/gorm"
    "connect4-backend/internal/ws"
    "connect4-backend/internal/matchmaking"
    "connect4-backend/internal/game"
)

func SetupRoutes(hub *ws.Hub, matcher *matchmaking.Matcher, gm *game.Manager, db *gorm.DB) *mux.Router {
    r := mux.NewRouter()

    r.HandleFunc("/ws", ws.ServeWS(hub, matcher, gm))

    r.HandleFunc("/leaderboard", GetLeaderboard(db)).Methods("GET")

    return r
}
