package api

import (
    "encoding/json"
    "net/http"

    "gorm.io/gorm"
)

func GetLeaderboard(db *gorm.DB) http.HandlerFunc {
    return func(w http.ResponseWriter, r *http.Request) {
        rows, err := db.Raw(`
            SELECT player1 AS username, COUNT(*) FILTER (WHERE winner = 1) AS wins
            FROM game_records
            GROUP BY player1
            ORDER BY wins DESC
            LIMIT 10
        `).Rows()
        if err != nil {
            http.Error(w, err.Error(), 500)
            return
        }

        type L struct { Username string; Wins int }
        var list []L

        for rows.Next() {
            var u L
            rows.Scan(&u.Username, &u.Wins)
            list = append(list, u)
        }

        json.NewEncoder(w).Encode(list)
    }
}
