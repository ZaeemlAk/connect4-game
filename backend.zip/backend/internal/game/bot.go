package game

type Bot struct{}

func NewBot() *Bot { return &Bot{} }

func (b *Bot) ChooseMove(board Board) int {
    // 1: winning move
    for c := 0; c < 7; c++ {
        clone := board
        if _, ok := clone.Drop(c, 2); ok && clone.CheckWinner() == 2 {
            return c
        }
    }
    // 2: block player
    for c := 0; c < 7; c++ {
        clone := board
        if _, ok := clone.Drop(c, 1); ok && clone.CheckWinner() == 1 {
            return c
        }
    }
    // 3: center move (best)
    if board[0][3] == 0 {
        return 3
    }
    // 4: heuristic fallback
    bestCol := -1
    bestScore := -999
    for c := 0; c < 7; c++ {
        clone := board
        if _, ok := clone.Drop(c, 2); ok {
            score := evaluateBoard(clone, 2)
            if score > bestScore {
                bestScore = score
                bestCol = c
            }
        }
    }
    return bestCol
}

func evaluateBoard(board Board, player int) int {
    // Very simple heuristic
    score := 0
    for r := 0; r < 6; r++ {
        for c := 0; c < 7; c++ {
            if board[r][c] == player {
                score += 1
            }
        }
    }
    return score
}
