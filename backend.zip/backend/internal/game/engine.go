package game

import (
    "github.com/google/uuid"
    "time"
)

type Game struct {
    ID        string
    Player1   string
    Player2   string
    Board     Board
    Turn      int
    Winner    int
    LastMove  int
    ExpiresAt time.Time
}

func NewGame(p1, p2 string) *Game {
    return &Game{
        ID:      uuid.New().String(),
        Player1: p1,
        Player2: p2,
        Turn:    1,
        ExpiresAt: time.Now().Add(30 * time.Second),
    }
}

func (g *Game) MakeMove(col int) bool {
    row, ok := g.Board.Drop(col, g.Turn)
    if !ok {
        return false
    }
    g.LastMove = col

    if win := g.Board.CheckWinner(); win != 0 {
        g.Winner = win
    } else if g.Board.IsFull() {
        g.Winner = 3 // draw
    }

    if g.Winner == 0 {
        if g.Turn == 1 { g.Turn = 2 } else { g.Turn = 1 }
    }

    return true
}
