package game

type Board [6][7]int

func (b *Board) Drop(col, player int) (int, bool) {
    if col < 0 || col > 6 {
        return -1, false
    }
    for row := 5; row >= 0; row-- {
        if b[row][col] == 0 {
            b[row][col] = player
            return row, true
        }
    }
    return -1, false
}

func (b *Board) CheckWinner() int {
    // Horizontal, vertical, diagonal checks
    dirs := [][]int{
        {0, 1}, {1, 0}, {1, 1}, {1, -1},
    }

    for r := 0; r < 6; r++ {
        for c := 0; c < 7; c++ {
            if b[r][c] == 0 { continue }
            player := b[r][c]

            for _, d := range dirs {
                count := 1
                rr, cc := r, c

                for i := 0; i < 3; i++ {
                    rr += d[0]
                    cc += d[1]
                    if rr < 0 || rr >= 6 || cc < 0 || cc >= 7 { break }
                    if b[rr][cc] == player {
                        count++
                    } else { break }
                }
                if count == 4 {
                    return player
                }
            }
        }
    }
    return 0
}

func (b *Board) IsFull() bool {
    for c := 0; c < 7; c++ {
        if b[0][c] == 0 {
            return false
        }
    }
    return true
}
