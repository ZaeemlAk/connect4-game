package game

import (
    "sync"
    "time"

    "gorm.io/gorm"
    "connect4-backend/internal/kafka"
)

type Manager struct {
    games sync.Map
    db    *gorm.DB
    prod  *kafka.Producer
    bot   *Bot
}

func NewManager(db *gorm.DB, prod *kafka.Producer) *Manager {
    return &Manager{
        db: db,
        prod: prod,
        bot: NewBot(),
    }
}

func (m *Manager) CreateGame(p1, p2 string) *Game {
    g := NewGame(p1, p2)
    m.games.Store(g.ID, g)

    m.prod.EmitGameCreated(g)

    return g
}

func (m *Manager) GetGame(id string) (*Game, bool) {
    v, ok := m.games.Load(id)
    if !ok { return nil, false }
    return v.(*Game), true
}

func (m *Manager) Move(g *Game, col int, player int) bool {
    if g.Turn != player { return false }

    ok := g.MakeMove(col)
    if !ok { return false }

    m.prod.EmitMove(g, col, player)

    if g.Winner != 0 {
        m.prod.EmitGameOver(g)
        m.db.Save(&storage.GameRecord{
            ID: g.ID,
            Player1: g.Player1,
            Player2: g.Player2,
            Winner:  g.Winner,
        })
        m.games.Delete(g.ID)
    }
    return true
}

func (m *Manager) BotMove(g *Game) {
    col := m.bot.ChooseMove(g.Board)
    m.Move(g, col, 2)
}
