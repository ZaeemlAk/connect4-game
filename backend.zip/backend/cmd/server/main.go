package main

import (
    "log"
    "net/http"

    "connect4-backend/internal/api"
    "connect4-backend/internal/storage"
    "connect4-backend/internal/ws"
    "connect4-backend/internal/game"
    "connect4-backend/internal/matchmaking"
    "connect4-backend/internal/kafka"
)

func main() {
    db := storage.Connect()
    kafkaProducer := kafka.NewProducer("kafka:9092")
    hub := ws.NewHub()
    gameManager := game.NewManager(db, kafkaProducer)
    matcher := matchmaking.NewMatcher(gameManager)

    go hub.Run()
    go matcher.Run()

    router := api.SetupRoutes(hub, matcher, gameManager, db)

    log.Println("Backend running on :8080")
    log.Fatal(http.ListenAndServe(":8080", router))
}
